package app.maintenance.model;

public enum MaintenanceType {
    OIL_CHANGE,
    TIRE_ROTATION,
    FILTER_CHANGE,
    BRAKE_SERVICE,
    INSPECTION,
    OTHER
}
