package app.user.model;

public enum UserRole {
    USER,ADMIN
}
